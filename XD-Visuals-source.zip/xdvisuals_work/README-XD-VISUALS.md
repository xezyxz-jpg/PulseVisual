# XD Visuals — Minecraft 1.21.11 (Fabric)

This is a rebranded build of the supplied Mykvador source project. The in-game title screen, pause-menu entry, custom menu header, splash wordmark, welcome/update text, and mod metadata now identify the client as **XD Visuals**. The internal Java/resource namespace (`dev.minee`, `assets/minee`, and the `minee.*` translation keys) is intentionally retained to avoid breaking the existing mixins, shaders, textures, and localization lookups. The mod ID and config folder are `xdvisuals`.

## Visual feature mapping from the previous XZ Visuals client

| Previous XZ Visuals feature | Existing feature in this source | Notes |
|---|---|---|
| ChinaHat | Hats → China hat | Existing configurable hat rendering, size, height, spin, glow/rim and style controls. |
| General hit particles / hit flash | Hit Effects | Existing hit-triggered stars, hearts, sparks, slashes and flash effects. |
| HUD / crosshair | HUD editor + Crosshair | Existing configurable HUD widgets and custom crosshair. |
| Swing animation | Hand → Swing animation | Existing first-person swing styles and speed/strength controls. |
| Theme | Theme | Existing glass appearance, palette, accent and visual tuning. |
| Trail | Trail + Swing Trail | Existing player movement trail and weapon-swing trail cosmetics. |
| ViewModel | Hand / ViewModel | Existing per-hand position, rotation, scale and preset controls. |
| Pearl Tracer | Trajectories | The source predicts pearl flight paths, but it is not the same as the old persistent teleport-trail renderer. |
| Fire overlay | No matching module found | The old first-person fire-height/preset control has not yet been ported. |

The supplied source already contains additional visual and cosmetic modules (for example bloom, color grading, motion blur, nametags, trajectories, hats, wings, capes, particles, and world effects); these have been retained rather than replaced.

## Build

Requires JDK 21 and network access for the Gradle wrapper and Fabric dependencies. Run `gradlew.bat build` on Windows or `./gradlew build` on Linux/macOS. The expected JAR name is `xdvisuals-1.0.0+1.21.11.jar` under `build/libs/`.
