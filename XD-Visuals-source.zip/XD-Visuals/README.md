# XD Visuals

Client-side visual customization mod for Minecraft Java 1.21.11 (Fabric), Java 21.

## Build
Run `./gradlew build` (Windows: `gradlew.bat build`).
The distributable JAR is created in `build/libs/`.

## Status
This archive is a renamed working source tree based on the uploaded Mykvador project.
It has not yet been compiled in this environment because Gradle distribution download
is unavailable here. Previous XZ Visuals modules still need compatibility porting;
the existing project already contains equivalents for several features (HUD,
Target HUD, Crosshair, Trail, Swing Trail, Theme, Hats, and Hand).
