package dev.xdvisuals.compat;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.xdvisuals.gui.menu.MenuScreen;


public final class XDVisualsModMenu implements ModMenuApi {
   public ConfigScreenFactory<?> getModConfigScreenFactory() {
      return MenuScreen::new;
   }
}
