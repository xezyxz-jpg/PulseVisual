package dev.xdvisuals;

import dev.xdvisuals.config.BuildLinks;
import dev.xdvisuals.config.ConfigManager;
import dev.xdvisuals.config.CrashGuard;
import dev.xdvisuals.config.UpdateChecker;
import dev.xdvisuals.gui.HudEditorScreen;
import dev.xdvisuals.gui.XDVisualsMenuButton;
import dev.xdvisuals.gui.PersonalTest;
import dev.xdvisuals.gui.PromoRecorder;
import dev.xdvisuals.gui.ScreensTest;
import dev.xdvisuals.gui.WorldTest;
import dev.xdvisuals.gui.menu.MenuScreen;
import dev.xdvisuals.gui.screen.GlassSearchField;
import dev.xdvisuals.gui.screen.PauseDesign;
import dev.xdvisuals.gui.screen.PlayerPreview;
import dev.xdvisuals.gui.screen.TitleDesign;
import dev.xdvisuals.hud.GameStats;
import dev.xdvisuals.hud.TargetTracker;
import dev.xdvisuals.module.Modules;
import dev.xdvisuals.module.impl.visual.BlockOutlineModule;
import dev.xdvisuals.notify.Notifications;
import dev.xdvisuals.render.GlowEngine;
import dev.xdvisuals.render.Shaders;
import dev.xdvisuals.render.font.Fonts;
import dev.xdvisuals.render.world.CosmeticsLayer;
import dev.xdvisuals.render.world.WorldCosmetics;
import dev.xdvisuals.server.ServerProfiles;
import java.util.Locale;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStarted;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.AfterEntities;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.BeforeBlockOutline;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.EndMain;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.StartMain;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterRender;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class XDVisualsClient implements ClientModInitializer {
   public static final String MOD_ID = "xdvisuals";
   public static final Logger LOGGER = LoggerFactory.getLogger("XDVisuals");
   private static final boolean DEMO = Boolean.getBoolean("xdvisuals.demo");
   private static final String UI_TEST = readUiTest();
   private static boolean demoOpened;
   private static boolean welcomed;

   public static String uiTest() {
      return UI_TEST;
   }

   private static String readUiTest() {
      String value = System.getProperty("xdvisuals.uitest", "false").trim();
      return !value.isEmpty() && !value.equalsIgnoreCase("false") ? value.toLowerCase(Locale.ROOT) : null;
   }

   public static String version() {
      String full = fullVersion();
      int plus = full.indexOf(43);
      return plus > 0 ? full.substring(0, plus) : full;
   }

   public static String fullVersion() {
      return FabricLoader.getInstance().getModContainer("xdvisuals").map(mod -> mod.getMetadata().getVersion().getFriendlyString()).orElse("dev");
   }

   public void onInitializeClient() {
      Shaders.register();
      PlayerPreview.register();
      Fonts.preload();
      Modules.init();
      ClientLifecycleEvents.CLIENT_STARTED.register((ClientStarted)client -> {
         ConfigManager.load();
         Modules.onConfigLoaded();
         ServerProfiles.restoreAfterCrash();
         CrashGuard.onStart();
         UpdateChecker.start(Modules.notifications() == null || Modules.notifications().checkUpdates());
      });
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)client -> {
         ConfigManager.save();
         CrashGuard.onStop();
      });
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> {
         Modules.onTick();
         ConfigManager.tick();
         if (UI_TEST != null) {
            WorldTest.tick(client);
            PromoRecorder.tick(client);
            ScreensTest.tick(client);
            PersonalTest.tick(client);
         }
      });
      HudRenderCallback.EVENT.register((HudRenderCallback)(graphics, deltaTracker) -> {
         Modules.onHud(graphics, deltaTracker);
         if (Minecraft.getInstance().screen == null) {
            Notifications.render(graphics);
         }
      });
      ScreenEvents.AFTER_INIT.register((AfterInit)(client, screen, width, height) -> {
         if (UI_TEST != null) {
            ScreenEvents.afterRender(screen).register((AfterRender)(current, graphics, mouseX, mouseY, delta) -> {
               if (WorldTest.tooltipDemo) {
                  graphics.setTooltipForNextFrame(client.font, new ItemStack(Items.DIAMOND_SWORD), width / 2 + 40, height / 2 - 30);
                  graphics.renderDeferredElements();
               }
            });
         }
      });
      ScreenEvents.AFTER_INIT
         .register(
            (AfterInit)(client, screen, width, height) -> {
               ScreenEvents.afterRender(screen).register((AfterRender)(current, graphics, mouseX, mouseY, delta) -> Notifications.render(graphics));
               if (Modules.containerSearch() != null) {
                  GlassSearchField search = Modules.containerSearch().attach(screen);
                  if (search != null) {
                     Screens.getButtons(screen).add(search);
                  }
               }

               if (screen instanceof TitleScreen title) {
                  Screens.getButtons(screen).add(new XDVisualsMenuButton(screen, width - 74, 8, 66, 20));
                  TitleDesign.layout(title, width, height);
               } else if (screen instanceof PauseScreen pause && pause.showsPauseMenu()) {
                  if (PauseDesign.active()) {
                     PauseDesign.layout(pause, width, height);
                  } else {
                     Screens.getButtons(screen).add(new XDVisualsMenuButton(screen, width - 74, 8, 66, 20));
                  }
               }

               if (!welcomed && screen instanceof TitleScreen) {
                  welcomed = true;
                  Notifications.show(
                     Notifications.Kind.INFO,
                     I18n.get("xdvisuals.notify.welcome.title", new Object[]{version()}),
                     I18n.get("xdvisuals.notify.welcome.subtitle", new Object[0])
                  );
               }

               if (DEMO
                  && !demoOpened
                  && screen instanceof TitleScreen
                  && !WorldTest.handles(UI_TEST)
                  && !PromoRecorder.handles(UI_TEST)
                  && !"screens".equals(UI_TEST)
                  && !"personal".equals(UI_TEST)) {
                  demoOpened = true;
                  if ("hud".equals(UI_TEST)) {
                     client.schedule(() -> client.setScreen(new HudEditorScreen(() -> screen)));
                  } else {
                     client.schedule(() -> client.setScreen(new MenuScreen(screen)));
                  }
               }
            }
         );
      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> client.execute(() -> {
         Modules.serverWarning().onJoin();
         if (Modules.eventSounds() != null) {
            Modules.eventSounds().onJoin();
         }

         ServerProfiles.onJoin();
         GameStats.sessionStarted();
      }));
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> {
         GameStats.sessionEnded();
         client.execute(ServerProfiles::onLeave);
      });
      TargetTracker.register();
      WorldRenderEvents.START_MAIN.register((StartMain)context -> GlowEngine.beginWorld());
      WorldRenderEvents.AFTER_ENTITIES.register((AfterEntities)context -> GlowEngine.refreshDepth());
      WorldRenderEvents.AFTER_ENTITIES.register(WorldCosmetics::render);
      LivingEntityFeatureRendererRegistrationCallback.EVENT
         .register((LivingEntityFeatureRendererRegistrationCallback)(entityType, renderer, helper, context) -> {
            if (renderer instanceof AvatarRenderer<?> player) {
               helper.register(new CosmeticsLayer(player));
            }
         });
      WorldRenderEvents.END_MAIN.register((EndMain)context -> {
         if (Modules.trajectories() != null) {
            Modules.guard(Modules.trajectories(), () -> Modules.trajectories().render(context));
         }
      });
      WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((BeforeBlockOutline)(context, outline) -> {
         BlockOutlineModule module = Modules.blockOutline();
         if (module != null && module.isEnabled() && outline != null) {
            BlockPos pos = outline.pos();
            Vec3 camera = context.worldState().cameraRenderState.pos;

            try {
               module.render(context.matrices(), outline.shape(), pos, camera.x, camera.y, camera.z);
               return false;
            } catch (RuntimeException e) {
               Modules.fail(module, e);
               return true;
            }
         } else {
            return true;
         }
      });
      WorldRenderEvents.END_MAIN.register((EndMain)context -> GlowEngine.endWorld());
      LOGGER.info("[XD Visuals] initialized, version {}, {} modules", version(), Modules.all().size());

      for (String link : BuildLinks.all()) {
         LOGGER.info("[XD Visuals] official: {}", link);
      }
   }
}
