package dev.xdvisuals.mixin;

import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;


@Mixin(MouseHandler.class)
public interface MouseHandlerAccessor {
   @Accessor("xpos")
   void xdvisuals$setX(double var1);

   @Accessor("ypos")
   void xdvisuals$setY(double var1);
}
