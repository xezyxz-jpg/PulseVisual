package dev.xdvisuals.mixin;

import dev.xdvisuals.render.gpu.ItemAlpha;
import net.minecraft.client.gui.render.state.GuiItemRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(GuiItemRenderState.class)
public abstract class GuiItemRenderStateMixin implements ItemAlpha.Holder {
   @Unique
   private float xdvisuals$alpha = 1.0F;

   @Inject(method = "<init>", at = @At("TAIL"))
   private void xdvisuals$rememberAlpha(CallbackInfo ci) {
      this.xdvisuals$alpha = ItemAlpha.current;
   }

   @Override
   public float xdvisuals$alpha() {
      return this.xdvisuals$alpha;
   }
}
