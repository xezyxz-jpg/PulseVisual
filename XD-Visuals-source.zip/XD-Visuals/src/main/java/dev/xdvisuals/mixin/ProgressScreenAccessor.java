package dev.xdvisuals.mixin;

import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;


@Mixin(ProgressScreen.class)
public interface ProgressScreenAccessor {
   @Accessor("header")
   Component xdvisuals$header();

   @Accessor("stage")
   Component xdvisuals$stage();

   @Accessor("progress")
   int xdvisuals$progress();
}
