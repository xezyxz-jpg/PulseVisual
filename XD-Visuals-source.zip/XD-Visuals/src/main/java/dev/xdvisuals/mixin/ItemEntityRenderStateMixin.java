package dev.xdvisuals.mixin;

import dev.xdvisuals.module.impl.world.ItemPhysicsModule;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;


@Mixin(ItemEntityRenderState.class)
public abstract class ItemEntityRenderStateMixin implements ItemPhysicsModule.State {
   @Unique
   private boolean xdvisuals$onGround;
   @Unique
   private int xdvisuals$id;
   @Unique
   private boolean xdvisuals$block;

   @Override
   public void xdvisuals$physics(boolean onGround, int id, boolean block) {
      this.xdvisuals$onGround = onGround;
      this.xdvisuals$id = id;
      this.xdvisuals$block = block;
   }

   @Override
   public boolean xdvisuals$onGround() {
      return this.xdvisuals$onGround;
   }

   @Override
   public int xdvisuals$id() {
      return this.xdvisuals$id;
   }

   @Override
   public boolean xdvisuals$block() {
      return this.xdvisuals$block;
   }
}
