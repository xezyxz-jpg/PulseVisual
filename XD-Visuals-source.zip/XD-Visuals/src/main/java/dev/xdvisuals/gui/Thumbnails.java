package dev.xdvisuals.gui;

import com.mojang.blaze3d.platform.NativeImage;
import dev.xdvisuals.XDVisualsClient;
import dev.xdvisuals.render.ImageFiles;
import dev.xdvisuals.render.gpu.XDVisualsTexture;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;


public final class Thumbnails {
   private static final Map<Path, Thumbnails.Thumbnail> CACHE = new HashMap<>();
   private static final Thumbnails.Thumbnail BROKEN = new Thumbnails.Thumbnail(null, 1, 1);

   private Thumbnails() {
   }

   public static Thumbnails.Thumbnail get(Path file) {
      Thumbnails.Thumbnail thumbnail = CACHE.computeIfAbsent(file, Thumbnails::load);
      return thumbnail == BROKEN ? null : thumbnail;
   }

   private static Thumbnails.Thumbnail load(Path file) {
      try {
         NativeImage image = ImageFiles.toNative(ImageFiles.read(file, 256));
         XDVisualsTexture texture = new XDVisualsTexture("thumbnail", image).filter(true, false);
         return new Thumbnails.Thumbnail(texture, image.getWidth(), image.getHeight());
      } catch (IOException | RuntimeException e) {
         XDVisualsClient.LOGGER.warn("[XD Visuals] cannot read picture {}", file, e);
         return BROKEN;
      }
   }

   public record Thumbnail(XDVisualsTexture texture, int width, int height) {
   }
}
