package dev.xdvisuals.module.impl;

import dev.xdvisuals.module.Category;
import dev.xdvisuals.module.Module;


public final class KeysModule extends Module {
   public KeysModule() {
      super("keys", Category.INTERFACE, true);
   }

   @Override
   public int icon() {
      return 57988;
   }

   @Override
   public boolean isAlwaysOn() {
      return true;
   }
}
