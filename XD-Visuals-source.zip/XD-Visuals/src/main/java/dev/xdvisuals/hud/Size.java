package dev.xdvisuals.hud;

public record Size(float width, float height) {
}
