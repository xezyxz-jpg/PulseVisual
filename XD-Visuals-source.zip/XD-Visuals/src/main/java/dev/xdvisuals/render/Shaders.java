package dev.xdvisuals.render;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.xdvisuals.render.gpu.XDVisualsShader;


public final class Shaders {
   private static final VertexFormat.Mode QUADS = VertexFormat.Mode.QUADS;
   private static final XDVisualsShader SURFACE = XDVisualsShader.create("surface", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader LIQUID_GLASS = XDVisualsShader.create("liquid_glass", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader TEXT = XDVisualsShader.create("sdf_text", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader KAWASE_DOWN = XDVisualsShader.create("kawase_down", DefaultVertexFormat.POSITION, QUADS);
   private static final XDVisualsShader KAWASE_UP = XDVisualsShader.create("kawase_up", DefaultVertexFormat.POSITION, QUADS);
   private static final XDVisualsShader ROUNDED_IMAGE = XDVisualsShader.create("rounded_image", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader CHARACTER = XDVisualsShader.create("character", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader POST_GRADE = XDVisualsShader.create("post_grade", DefaultVertexFormat.POSITION, QUADS);
   private static final XDVisualsShader SOFT_SPRITE = XDVisualsShader.create("soft_sprite", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader GLOW_COMPOSITE = XDVisualsShader.create("glow_composite", DefaultVertexFormat.POSITION, QUADS);
   private static final XDVisualsShader SILHOUETTE = XDVisualsShader.create("silhouette", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader BLACK_HOLE = XDVisualsShader.create("black_hole", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final XDVisualsShader NEBULA = XDVisualsShader.create("nebula", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);

   private Shaders() {
   }

   public static void register() {
   }

   public static XDVisualsShader softSprite() {
      return SOFT_SPRITE;
   }

   public static XDVisualsShader silhouette() {
      return SILHOUETTE;
   }

   public static XDVisualsShader glowComposite() {
      return GLOW_COMPOSITE;
   }

   public static XDVisualsShader surface() {
      return SURFACE;
   }

   public static XDVisualsShader liquidGlass() {
      return LIQUID_GLASS;
   }

   public static XDVisualsShader text() {
      return TEXT;
   }

   public static XDVisualsShader kawaseDown() {
      return KAWASE_DOWN;
   }

   public static XDVisualsShader character() {
      return CHARACTER;
   }

   public static XDVisualsShader roundedImage() {
      return ROUNDED_IMAGE;
   }

   public static XDVisualsShader postGrade() {
      return POST_GRADE;
   }

   public static XDVisualsShader kawaseUp() {
      return KAWASE_UP;
   }

   public static XDVisualsShader blackHole() {
      return BLACK_HOLE;
   }

   public static XDVisualsShader nebula() {
      return NEBULA;
   }
}
